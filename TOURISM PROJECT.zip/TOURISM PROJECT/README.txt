This is basically a tourism management project in c language
A check id and info file is created as soon as you compile the project
Do show more support and get connected with me 
Thank you !
