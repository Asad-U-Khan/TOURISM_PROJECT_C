#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <stdlib.h>

int d,m,y;
int d1,m1,y2;

void dest();
void swat();
void naran();
void kashmir();
void skardu();
void hunza();
void kumrat();
void out_details();
void out_ticket(int a[],int cnt);
void details(int cnt,int cno);
int check(int id);
void trains(int id);
void hotels();
int mainmenu();

struct info
{
	int age;
	int cost;
	int days;
	char hname[30];
	char dest[15];
	char name[30];
	char gender;
	char med;
	char veg;
	float time;
	char tname[30];
	char shift[3];
} i;


void out_details()
{
	 system("cls");
	 
	 int id,no,flag=0;
	 
	 printf("\n\tPassenger Details :\n");
	 printf(" \n\tEnter Id of person you want to search:  ");
	 scanf("%d", &id);
	 FILE *f;
  	 f=fopen("info.txt", "r");
  	 
	 while (!feof(f))
	   {
		  fscanf(f,"%d %s %d %c %c %c %d %s %s %f %s %d %d %d %d %d %d %s",&no,&i.name,&i.age,&i.gender,&i.veg,&i.med,&i.cost,&i.dest,&i.tname,&i.time,&i.shift,&d,&m,&y,&d1,&m1,&y2,&i.hname);
	      
		  if(id==no)
		  {
		      printf("\n\n\tId : %d",no);
		      printf("\n\tName : %s\t\t\t\t Hotel Name : %s ", i.name,i.hname);
		      printf("\n\tAge : \t%d\t\t\t\t Check-in : %d/%d/%d ",i.age,d,m,y);
		      printf("\n\tGender : %c\t\t\t\t Check-out : %d/%d/%d",i.gender,d1,m1,y2);
		      printf("\n\tMedical Problem : %c\t \t\t\t",i.med);
		      printf("\n\tVegan : %c",i.veg);
              printf("\n\tDestination : %s",i.dest);
              printf("\n\tTrain Name : %s",i.tname);
              printf("\n\tDeparture Time : %.2f %s",i.time,i.shift);
              printf("\n\n\tPress Enter to continue .....");
	          flag=1;
		  }
           if(flag==1)
           {
              break;
		   }
       }
       
	 fclose(f);
	 if(flag==0)
	   {
		 printf("\nNo bill exists.");
		 printf("\nPress Enter to continue .....");
	   }
}


void out_ticket(int a[],int cnt)
{
	system("cls");
	
	int z,no,flag;
	
	FILE *f;
    printf("\n\n\t Displaying Ticket:");
  	
  for(z=0;z<cnt;++z)
   {   
     flag=0;
     f=fopen("info.txt", "r");
     
	 while (!feof(f))
	   {   
		 fscanf(f,"%d %s %d %c %c %c %d %s %s %f %s %d %d %d %d %d %d %s",&no,&i.name,&i.age,&i.gender,&i.veg,&i.med,&i.cost,&i.dest,&i.tname,&i.time,&i.shift,&d,&m,&y,&d1,&m1,&y2,&i.hname);
		 
		 if(a[z]==no)
		   {
		     printf("\n\n\tId : %d",no);
		     printf("\n\tName : %s\t\t\t\t Hotel Name : %s ", i.name,i.hname);
		     printf("\n\tAge : \t%d\t\t\t\t Check-in : %d/%d/%d ",i.age,d,m,y);
		     printf("\n\tGender : %c\t\t\t\t Check-out : %d/%d/%d",i.gender,d1,m1,y2);
		     printf("\n\tVegan : %c",i.veg);
		     printf("\n\tMedical Problem : %c",i.med);
             printf("\n\tDestination : %s",i.dest);
             printf("\n\tTrain Name : %s",i.tname);
             printf("\n\tDeparture Time : %.2f %s",i.time,i.shift);
             flag=1;
		   }
		   
         if(flag==1)
         break;
         
       }
     fclose(f);
   }
    printf("\n\n\t\tTotal Cost : %ld",i.cost);
    printf("\n\n\t\tBooking successfully done");
    printf("\n\n\t\t   Press Enter to go to main menu .....");
    
    getchar();
    mainmenu();
}


int check(int id)
{   
     int fi;
	 FILE *f1;

     f1=fopen("checkid.txt","w");

     fclose(f1);

     FILE *f;
	 f=fopen("checkid.txt","r+");
     while(!feof(f))
       {
	     fscanf(f,"%d",&fi);
	     if(fi==id)
	       {  
	         printf("\n\t Id already exists!\n\t Choose another one ! :\n");
	         return 1;
	       }
       }
     fclose(f);
     return 0;
}


void details(int cnt,int cno)
{
	int a[cnt];	
	int pos=0,res;
	
	switch(cno)
	{
		case 1:
		strcpy(i.dest,"Swat");
		break;
		case 2:
		strcpy(i.dest,"Naran");
		break;
		case 3:
		strcpy(i.dest,"Kashmir");
		break;
		case 4:
		strcpy(i.dest,"Skardu" );
		break;
		case 5:
		strcpy(i.dest,"Hunza");
		break;
		case 6:
		strcpy(i.dest,"Kumrat");
		break;
	}
	
	int x=0,id;
	
	while(x<cnt)
	{  
		system("cls");
		printf("\n\t\t Enter %d person details",x+1);
		a:
		printf("\n\n\t     Choose a travel id (1-100) : ");
	    scanf("%d",&id);
	    res=check(id);
	    
	    if(res==1)
	    goto a;
	    
	    printf("\n\t    Enter  Name , Age , Gender (M/F)  :\n\n");
	    FILE *f;
	    f=fopen("info.txt","a+");
	    
	    printf("\t    ");
	    scanf("%s", &i.name);
	    printf("\t    ");
	    scanf("%d",&i.age);
	    printf("\t    ");
	    getchar();
        i.gender=getchar();
        printf("\t    Are you a Vegan ? (Y/N): ");
        getchar();
        i.veg=getchar();
        printf("\t    Do you have any medical problem ? (Y/N): ");
        getchar();
        i.med=getchar();
        ((i.med=='Y' || i.med=='y')? printf("\n\t    We will take special measures for you") : 0);
        printf("\n\n\t\t   Press Enter to continue .....");
        getchar();
	    getchar();	
	    trains(id);
	    hotels();
	    
	    fprintf(f,"%d %s %d %c %c %c %d %s %s %f %s ",id,i.name,i.age,i.gender,i.veg,i.med,i.cost,i.dest,i.tname,i.time,i.shift);
	    fprintf(f," %d %d %d %d %d %d %s\n",d,m,y,d1,m1,y2,i.hname);
        fclose(f);
        a[x]=id;
        ++x;
	}
	out_ticket(a,cnt);
}


void hotels()
{
	 int n;
	
     system("cls");
	 printf("\n\t\t Choose Hotel :");
	 printf("\n\n\t1. Pearl Continental\t   Price : 9,000 per day");
	 printf("\n\n\t2. Avari\t           Price : 8,500 per day");
	 printf("\n\n\t3. Mariott\t           Price : 7,000 per day");
	 printf("\n\n\t4. Country Inn\t           Price : 7,500 per day");
	 printf("\n\n\t5. Galaxy\t           Price : 8,000 per day");
	 printf("\n\n\t Enter choice :  ");
	 scanf("%d", &n);
	 printf("\n\n\t Enter no. of days : ");
	 scanf("%d",&i.days);
	 
	 switch (n)
	   {
         case 1: 
         i.cost+=i.days*9000;
         strcpy(i.hname,"Pearl_Continental");
         break;
         case 2: 
         i.cost+=i.days*8500;
         strcpy(i.hname,"Avari");
         break;
         case 3: 
         i.cost+=i.days*7000;
         strcpy(i.hname,"Mariott");
         break;
         case 4: 
         i.cost+=i.days*7500;
         strcpy(i.hname,"Country_Inn");
         break;
         case 5: 
         i.cost+=i.days*8000;
         strcpy(i.hname,"Galaxy");
         break;
	   }
	
	 printf("\n\t Check-In Date\n");
	 printf("\n\t Enter day of check-in : ");
	 scanf("%d",&d);
	 printf("\n\t Enter month of check-in : ");
	 scanf("%d",&m);
	 printf("\n\t Enter year of check-in : ");
	 scanf("%d",&y);

	 d1=d+i.days;
	 m1=m;
	 y2=y;
	 if(d1>31)
	   {
	     d1=d1-31;
		 m1++;
		 if(m1>12)
		   {
			 m1=m1-12;
			 y2++;
		   }
	   }
     printf("\n\n\t\t   Press Enter to continue .....");
	 getchar();
	 getchar();
}
	
		
void trains(int id)
{
	    system("cls");
	    
		int choice;
	    printf("\n\n\t\t Trains Available : ");
	    printf("\n\n    1. Green Train :             Departure : 6.00 AM  Price : Rs6,000");
	    printf("\n    2. Tezgam Express :          Departure : 9.00 AM  Price : Rs5,500");
		printf("\n    3. Karakoram Express :       Departure : 1.00 PM  Price : Rs4,500");
		printf("\n    4. Khyber Express :          Departure : 5.00 PM  Price : Rs3,000");
		printf("\n    5. Shalimar Express :        Departure : 9.00 PM  Price : Rs2,500");
		printf("\n\n\t Enter choice :  ");
		scanf("%d",&choice);
		
		switch(choice)
	   {
           case 1: 
           i.cost+=6000;
           i.time=6.00;
           strcpy(i.shift,"AM");
           strcpy(i.tname,"Green_Train");
           break;
           case 2: 
           i.cost+=5500;
           i.time=9.00;
           strcpy(i.shift,"AM");
           strcpy(i.tname,"Tezgam_Express");
           break;
           case 3: 
           i.cost+=4500;
           i.time=1.00;
           strcpy(i.shift,"PM");
           strcpy(i.tname,"Karakoram_Express");
           break;
           case 4: 
           i.cost+=3000;
           i.time=5.00;
           strcpy(i.shift,"PM");
           strcpy(i.tname,"Khyber_Express");
           break;
           case 5: 
           i.cost+=2500;
           i.time=9.00;
           strcpy(i.shift,"PM");
           strcpy(i.tname,"Shalimar_Express");
           break;
       }
       
	   FILE *p;
       p=fopen("checkid.txt","a+");      
	   fprintf(p,"%d \n",id);
       fclose(p);
       
       printf("\n\n\t\t   Press Enter to continue .....");
	   getchar();
	   getchar(); 
}


void dest()
{
	system("cls");
	int n;
	printf("\n\t Destinations :");
	printf("\n\n\t 1. Swat");
	printf("\n\n\t 2. Naran Kaghan Valley");
	printf("\n\n\t 3. Kashmir Neelum Valley");	
	printf("\n\n\t 4. Skardu ");
	printf("\n\n\t 5. Hunza Valley");
	printf("\n\n\t 6. Kumrat Valley");
	
	printf("\n\n\t Enter your choice :  ");
	scanf("%d", &n);
	
	switch (n)
	{
	   case 1:
	   swat();
	   break;
	   case 2:
	   naran();
       break;
	   case 3:
	   kashmir();
	   break;
	   case 4:
	   skardu();
	   break;
	   case 5:
	   hunza();
	   break;
	   case 6:
	   kumrat();
	   break;
	}
}


void swat()
{
	 int cnt;
	 system("cls");
	 printf("\n\t\tWelcome to Swat Tour  !!!\n");
     printf("\n\t\t    Enter no. of people ");
     scanf("%d",&cnt);
	 details(cnt,1);	
}


void naran()
{
	 int  cnt;
	 system("cls");	
	 printf("\n\t\tWelcome to Kaghan Naran Valley Tour  !!!\n");
     printf("\n\t\t    Enter no. of people ");
     scanf("%d",&cnt);
	 details(cnt,2);	
}


void kashmir()
{
	 int  cnt;
	 system("cls");
	 printf("\n\t\tWelcome to Kashmir Neelum Valley Tour  !!!\n");
     printf("\n\t\t    Enter no. of people ");
     scanf("%d",&cnt);
	 details(cnt,3);	
}


void skardu()
{
	 int  cnt;
	 system("cls");
	 printf("\n\t\tWelcome to Skardu Tour  !!!\n");
     printf("\n\t\t    Enter no. of people ");
     scanf("%d",&cnt);
	 details(cnt,4);	
}


void hunza()
{
	 int  cnt;
	 system("cls");
	 printf("\n\t\tWelcome to Hunza Valley Tour  !!!\n");
     printf("\n\t\t    Enter no. of people ");
     scanf("%d",&cnt);
	 details(cnt,5);	
}


void kumrat()
{
	 int  cnt;
     system("cls");
	 printf("\n\t\tWelcome to Kumrat Valley Tour  !!!\n");
     printf("\n\t\t    Enter no. of people ");
     scanf("%d",&cnt);
	 details(cnt,6);	
}
	

int mainmenu(void)
{
	 int n;
     system("cls");
	 printf("\n\tMain Menu :");
	 printf("\n\n\t1. Choose Destination \n\n\t2. Compute Bill\n\n\t3. Exit\n\n\tEnter Choice :  ");
	 scanf("\n%d", &n);
	 
	 switch (n)
	   {
	     case 1:
	     dest();
	     break;
	     case 2:
	     out_details();
	     break;
	     case 3: 
	     return 0;
       }
     getch();
     mainmenu();
}


int main(void)
{
	 system ("COLOR 70");
	 system("cls");
	 printf("\n\n\n\t\t\t\t\t============================================\n");
	 printf("\t\t\t\t\tTOURISM MANAGEMENT SYSTEM BY ASAD ULLAH KHAN\n");
	 printf("\t\t\t\t\t============================================");
	 printf("\n\n\n\n\t\t\t\t   Press Enter to continue .....");
	 getchar();
	 mainmenu();
}
